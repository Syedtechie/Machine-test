function calculateSupply(){
  var myAge=document.getElementById('myAge').value;
  var maxAge=100;
  var cupsAmount= document.getElementById('myTea').value; 
  var totalSupply=(cupsAmount * 365) * (maxAge - myAge); 
  var result= document.getElementById('leftCups').value=totalSupply; 
}